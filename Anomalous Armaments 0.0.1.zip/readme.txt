
>>Compatibility Issues<<
Mods that change lootdrop data for the "wreck" (Ashes of The Domain- Vaults of Knowledge for example) can cause the weapons to not spawn in wrecked ships, which means they probably wont spawn at all. This can be fixed by adding "randomweapons:0.15" (or whatever probability you like) in the drop_random column of the salvage_data.csv of the mod.

Also, weapons can rarily pop up in locations they shouldnt be, when said locations were added or modified by mods to drop all weapon groups



To create your own randomized versions of vanilla (and modded) weapons, do the following: (requires pandas lib)
1. Delete the weapons folder that comes with the mod 
2. Copy(!)the entire weapons folder from starsector-core/data to this mods data folder
3. Place the weapon_randomizer.py script in the weapons folder
3.5(optional) add other weapons from mods: copy over the needed .wpn files (if needed, the .proj files too) and add their data to the weapon_data.csv file thats in the same folder as the python script (built-ins and special stuff could potentially cause trouble, and removing the mod you took the weapons from while keeping this one active will probably crash your game)
4. Run the script (modify it first if you like)
5. Rename or delete the original weapon_data.csv and rename the newly generated .csv file to weapon_data.csv
6. Find the newly generated descriptions.csv file and place it in data/strings
Thats it

Feel free to modify, use and reuse this as you wish


