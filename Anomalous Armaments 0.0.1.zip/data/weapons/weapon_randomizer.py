import pandas
import os
import random
import re

rare_wpn_version_count= 4#how many lightly modified variants of every weapon will be created 
#(if its more than eight (god bless), add some new names in newnames() method)

leg_wpn_version_count = 3#how many heavily modified variants of every weapon will be created 
#(if its more than three, add some new names in newnames() method)

#see randomize_rare() and randomize_Legendary() below to change how much the stats can change in either direction

changetype_rare = True #

script_directory = os.path.dirname(os.path.abspath(__file__))
filepath= os.path.join(script_directory, "weapon_data.csv")
newcsvloc= os.path.join(script_directory, "weapon_data_r.csv")
newDesccsvloc= os.path.join(script_directory, "descriptions.csv")
print(os.path.exists(script_directory))
v_weapons = pandas.read_csv(filepath)
#print(v_weapons)
new_weapons = pandas.DataFrame(columns=v_weapons.columns)
description = pandas.DataFrame(columns =["id","type","text1","text2","text3","notes"])




def randomize_rare(number, isfloat = False):
    change = 1 + (random.randint(-20,80)/100) #numbers in randint represent percentage
    #                if negative number goes above 100, expect to see negative values in game (dont know if they will work)
    number = (number*change)
    if isfloat == False:
        return int(number)
    else:
        return "{:0.2f}".format(number)
    
def randomize_Legendary(number, isfloat = False):
    change = 1 + (random.randint(-75,200)/100)
    number = (number*change)
    if isfloat == False:
        return int(number)
    else:
        return "{:0.2f}".format(number)
    
def newnames(name, count, rarity = "r"):#r once stood for rare, too lazy to change it
    if rarity == "r":
        #if you want more than 8 different "rare" versions of every weapon, add more names for them here
        names = ["Weird", "Strange", "Distorted", "Eerie", "Mysterious", "Uncanny","Abnormal", "Bizarre"]
        
        new_name = (f"{names[count]} " + name)
    else:
        #as above, add more names here if you create more than 3 "legendary" or whatever weapon variants
        cnames = ["Corrupted", "Grotesque", "Frightening"]
        new_name = (f"{cnames[count]} "+ name)
    return new_name

def newids(name, count, rarity = "r"):
    if rarity == "r":
        new_id = ("w"+str(count)+"_"+ name)
    else:
        new_id = ("c"+str(count)+"_"+ name)
    return new_id

def newtag(tags = None):
    #new_tag = (tags+", randomweapons") #use this if you want the new weapons to spawn everywhere(currently untested)
    new_tag = "randomweapons, no_sell, no_dealer"
    return new_tag

#def stripnonASCII(text):
    return ''.join(char for char in text if ord(char) < 128)

def wpn_file_exists(orig_id):
    filename = (f"{orig_id}.wpn")
    wpnfilepath = os.path.join(script_directory, filename)
    return os.path.exists(wpnfilepath)

def generateWPNfile(orig_id, neue_id):
    filename = (f"{orig_id}.wpn")
    wpnfilepath = os.path.join(script_directory, filename)
    #print(wpnfilepath)
    with open(wpnfilepath,"r") as orig_wpnfile:
        zeilen = orig_wpnfile.readlines()

    modified_lines = []
    for line in zeilen:
        if '"id"' in line:
            modified_lines.append(f'\t"id":"{new_id}",\n')
        else:
            modified_lines.append(line)
    
    new_wpnfilepath = os.path.join(script_directory, f"{neue_id}.wpn")
    with open(new_wpnfilepath, "w") as new_wpnfile:
        new_wpnfile.writelines(modified_lines)

        #orig_content = orig_wpnfile.read().decode("cp1252")
        #tripped_content = stripnonASCII(orig_content)
        

        #orig_wpn_data = json.loads(json.dumps(stripped_content))#scheiss json man

    #orig_wpn_data["id"] = neue_id
    #newWPNfilepath = os.path.join(script_directory, f"{neue_id}.wpn")
    #with open(newWPNfilepath, "w") as newWPNfile:
        #json.dump(orig_wpn_data, newWPNfile, indent=4)


def add_description(id, rarity):
    global description
    r_descriptions= [
        "Although it looks ordinary, something has happened in this weapon's past that has greatly altered its capabilities.",
        "Despite its ordinary looks, there is definitely something wrong with this weapon.",
        "You feel the strange urge to keep and use this weapon at all costs. Everything will turn out good if you use this weapon.",
        "Members of the salvage crew report the sound of indistinct radio chatter coming from inside the machinery.",
        "First reports from the salvage crew claim that the weapon feels warm to the touch and emits a low humming tone when patted.",
        "Members of the salvage crew are concerned about the amount of warnings that were frantically scribbled on the side of this weapon.",
        "This weapon reportedly smells very pleasant, even in space.",
        "The weapon was allegedly found together with a small diary containing hundreds of entries written from the perspective of the machine."
        
    ]
    l_descriptions=[
        "Several members of the salvaging crew report that they could hear voices coming from inside the weapon when alone with it. Taking a look at it yourself, you get the strong urge to squeeze yourself inside of it and merge with the machinery.",
        "In quiet moments, when you place your ear at the backside of the weapon and listen closely, a strange yet familiar melody can be heard from inside.",
        "After an incident during the examination of this weapon, most salvagers refuse to go anywhere near it.",
        "Somewhat disturbed, your chief engineer clumsily confides to you that this very weapon has been appearing in his dreams for the last two weeks.",
        "The inside of this weapon seems to be filled entirely with a strange black goo. When a member of the salvage crew tried to take a sample, the machine reportedly screamed at him.",
        "If the reports from the salvage crew are to be believed, this weapon was reportedly found surrounded by various offerings and sacrifices."
    ]
    if rarity == "r":
        desc = random.choice(r_descriptions)
    else:
        desc = random.choice(l_descriptions)
    
    new_data = {
        "id":id,
        "type": "WEAPON",
        "text1": desc
    }

    new_desc = pandas.DataFrame([new_data])
    description = pandas.concat([description, new_desc], ignore_index=True)

    return description
    

    

#name,id,tier,rarity,base value,range,damage/second,damage/shot,emp,impact,turn rate,OPs,ammo,ammo/sec,reload size,type,energy/shot,energy/second,chargeup,chargedown,burst size,burst delay
#,min spread,max spread,spread/shot,spread decay/sec,beam speed,proj speed,launch speed,flight time,proj hitpoints,autofireAccBonus,extraArcForAI,hints,
#tags,groupTag,tech/manufacturer,for weapon tooltip>>,primaryRoleStr,speedStr,trackingStr,turnRateStr,accuracyStr,customPrimary,customPrimaryHL,customAncillary,customAncillaryHL,noDPSInTooltip,number
normal_letter_pattern = re.compile(r'^,+') 

for index, row in v_weapons.iterrows():
  


    if pandas.isnull(row["name"]) or pandas.isnull(row["id"]):
        # Skip this row if all values are empty
        print(f"Skipping row {index} because of empty key values")
        continue
    if not wpn_file_exists(str.lower(v_weapons.loc[index,"id"])):
        print(f"skipping row beacause no {str.lower(v_weapons.loc[index,"id"])}.wpn file found")
        continue

    if not re.match(normal_letter_pattern,  str(row['name']).strip()): #probably not needed anymore, crashes were caused by something else

        for i in range(rare_wpn_version_count):
            new_weapon = row.copy()
            temp_df = pandas.DataFrame([new_weapon])
            
            #name
            old_name = v_weapons.loc[index,"name"]
            print(type(old_name), old_name)
            new_name = newnames(old_name,i)
            temp_df["name"] = new_name

            #id
            old_id = v_weapons.loc[index,"id"]
            new_id = newids(old_id,i)
            temp_df["id"] = new_id

            #tag
            old_tags = v_weapons.loc[index,"tags"]
            new_tag= newtag(old_tags)
            temp_df["tags"] = new_tag

            #neue .wpn datei mit angepasster id
            generateWPNfile(old_id, new_id)

            
            add_description(new_id, "r")

            

            #change damage type on one version of zhe weapon
            if not pandas.isnull(row["type"]) and i == 2 or 3:#the second and third created weapon will have its damage type changed, to add more, add or
                types= ["HIGH_EXPLOSIVE", "KINETIC", "FRAGMENTATION", "ENERGY"]
                new_type = random.choice(types)
                temp_df["type"] = new_type


            #randomize range
            if not pandas.isnull(row["range"]):
                old_range = v_weapons.at[index,"range"]
                new_range= randomize_rare(old_range)
                temp_df["range"] = new_range

            #randomize damage/shot
            if not pandas.isnull(row["damage/shot"]):
                old_shot_damage = v_weapons.at[index,"damage/shot"]
                new_shot_damage= randomize_rare(old_shot_damage)
                temp_df["damage/shot"] = old_shot_damage

            # Randomize emp
            if not pandas.isnull(row["emp"]):
                old_emp = v_weapons.at[index, "emp"]
                new_emp = randomize_rare(old_emp)
                temp_df["emp"] = new_emp

            # Randomize impact (float)
            if not pandas.isnull(row["impact"]):
                old_impact = v_weapons.at[index, "impact"]
                new_impact = randomize_rare(old_impact, True)
                temp_df["impact"] = new_impact

            # Randomize turn rate
            if not pandas.isnull(row["turn rate"]):
                old_turn_rate = v_weapons.at[index, "turn rate"]
                new_turn_rate = randomize_rare(old_turn_rate)
                temp_df["turn rate"] = new_turn_rate

            # Randomize ammo
            if not pandas.isnull(row["ammo"]):
                old_ammo = v_weapons.at[index, "ammo"]
                new_ammo = randomize_rare(old_ammo)
                if random.randint(1,8) == 8: #Chance to make ammo infinite, to increase chance, increase first number in tupel
                    temp_df["ammo"] = None
                else:
                    temp_df["ammo"] = new_ammo + 2 # 0 ammo by default sucks

            # Randomize reload size
            if not pandas.isnull(row["reload size"]):
                old_reload_size = v_weapons.at[index, "reload size"]
                new_reload_size = randomize_rare(old_reload_size)
                temp_df["reload size"] = new_reload_size

            # Randomize energy/shot
            if not pandas.isnull(row["energy/shot"]):
                old_energy_shot = v_weapons.at[index, "energy/shot"]
                new_energy_shot = randomize_rare(old_energy_shot)
                temp_df["energy/shot"] = new_energy_shot

            # Randomize energy/second
            if not pandas.isnull(row["energy/second"]):
                old_energy_second = v_weapons.at[index, "energy/second"]
                new_energy_second = randomize_rare(old_energy_second)
                temp_df["energy/second"] = new_energy_second

            # Randomize chargeup (float)
            if not pandas.isnull(row["chargeup"]):
                old_chargeup = v_weapons.at[index, "chargeup"]
                new_chargeup = randomize_rare(old_chargeup, True)
                temp_df["chargeup"] = new_chargeup

            # Randomize chargedown (float)
            if not pandas.isnull(row["chargedown"]):
                old_chargedown = v_weapons.at[index, "chargedown"]
                new_chargedown = randomize_rare(old_chargedown, True)
                temp_df["chargedown"] = new_chargedown

            # Randomize burst size
            if not pandas.isnull(row["burst size"]):
                old_burst_size = v_weapons.at[index, "burst size"]
                new_burst_size = randomize_rare(old_burst_size)
                if random.randint(2,8) == 8: #Chance to add burst to non burst weapons, to increase chance, increase first number in tupel
                    temp_df["burst size"] = new_burst_size +random.randint(1,10)# adds amount of burst projectiles
                else:
                    temp_df["burst size"] = new_burst_size

            # Randomize burst delay (float)
            if not pandas.isnull(row["burst delay"]):
                old_burst_delay = v_weapons.at[index, "burst delay"]
                new_burst_delay = randomize_rare(old_burst_delay, True)
                if random.randint(1,8) == 8: #Chance to (almost) remove delay
                    temp_df["burst delay"] = 0.01
                else:
                    temp_df["burst delay"] = new_burst_delay

            # Randomize min spread
            if not pandas.isnull(row["min spread"]):
                old_min_spread = v_weapons.at[index, "min spread"]
                new_min_spread = randomize_rare(old_min_spread)
                temp_df["min spread"] = new_min_spread

            # Randomize max spread
            if not pandas.isnull(row["max spread"]):
                old_max_spread = v_weapons.at[index, "max spread"]
                new_max_spread = randomize_rare(old_max_spread)
                temp_df["max spread"] = new_max_spread

            # Randomize proj speed
            if not pandas.isnull(row["proj speed"]):
                old_proj_speed = v_weapons.at[index, "proj speed"]
                new_proj_speed = randomize_rare(old_proj_speed)
                temp_df["proj speed"] = new_proj_speed
        

            new_weapons = pandas.concat([new_weapons, temp_df])







        #create Legendary versions
        for i in range(leg_wpn_version_count):
            new_weapon = row.copy()
            temp_df = pandas.DataFrame([new_weapon])
            
            #name
            old_name = v_weapons.loc[index,"name"]
            #print(type(old_name), old_name)
            new_name = newnames(old_name,i,"l")
            temp_df["name"] = new_name

            #id
            old_id = v_weapons.loc[index,"id"]
            new_id = newids(old_id,i,"l")
            temp_df["id"] = new_id

            #neue .wpn datei mit angepasster id
            generateWPNfile(old_id, new_id)

            add_description(new_id, "l")

            #tag
            old_tags = v_weapons.loc[index,"tags"]
            new_tag= newtag(old_tags)
            temp_df["tags"] = new_tag

            #change damage type on one version of the weapon
            if not pandas.isnull(row["type"]) and i == 1 or 2 or 3:
                types= ["HIGH_EXPLOSIVE", "KINETIC", "FRAGMENTATION", "ENERGY"]
                new_type = random.choice(types)
                temp_df["type"] = new_type


            #randomize range    
            if not pandas.isnull(row["range"]):
                old_range = v_weapons.at[index,"range"]
                new_range= randomize_Legendary(old_range)
                temp_df["range"] = new_range

            #randomize damage/shot
            if not pandas.isnull(row["damage/shot"]):
                old_shot_damage = v_weapons.at[index,"damage/shot"]
                new_shot_damage= randomize_Legendary(old_shot_damage)
                temp_df["damage/shot"] = old_shot_damage

            # Randomize emp
            if not pandas.isnull(row["emp"]):
                old_emp = v_weapons.at[index, "emp"]
                new_emp = randomize_Legendary(old_emp)
                temp_df["emp"] = new_emp

            # Randomize impact (float)
            if not pandas.isnull(row["impact"]):
                old_impact = v_weapons.at[index, "impact"]
                new_impact = randomize_Legendary(old_impact, True)
                temp_df["impact"] = new_impact

            # Randomize turn rate
            if not pandas.isnull(row["turn rate"]):
                old_turn_rate = v_weapons.at[index, "turn rate"]
                new_turn_rate = randomize_Legendary(old_turn_rate)
                temp_df["turn rate"] = new_turn_rate

            # Randomize ammo
            if not pandas.isnull(row["ammo"]):
                old_ammo = v_weapons.at[index, "ammo"]
                new_ammo = randomize_Legendary(old_ammo)
                if random.randint(4,8) == 8: #Chance to make ammo infinite
                    temp_df["ammo"] = None
                else:
                    temp_df["ammo"] = new_ammo + 5

            # Randomize reload size
            if not pandas.isnull(row["reload size"]):
                old_reload_size = v_weapons.at[index, "reload size"]
                new_reload_size = randomize_Legendary(old_reload_size)
                temp_df["reload size"] = new_reload_size

            # Randomize energy/shot
            if not pandas.isnull(row["energy/shot"]):
                old_energy_shot = v_weapons.at[index, "energy/shot"]
                new_energy_shot = randomize_Legendary(old_energy_shot)
                temp_df["energy/shot"] = new_energy_shot

            # Randomize energy/second
            if not pandas.isnull(row["energy/second"]):
                old_energy_second = v_weapons.at[index, "energy/second"]
                new_energy_second = randomize_Legendary(old_energy_second)
                temp_df["energy/second"] = new_energy_second

            # Randomize chargeup (float)
            if not pandas.isnull(row["chargeup"]):
                old_chargeup = v_weapons.at[index, "chargeup"]
                new_chargeup = randomize_Legendary(old_chargeup, True)
                if random.randint(4,8) == 8: #Chance to (almost) remove chargeup
                    temp_df["chargeup"] = 0.05
                else:
                    temp_df["chargeup"] = new_chargeup

            # Randomize chargedown (float)
            if not pandas.isnull(row["chargedown"]):
                old_chargedown = v_weapons.at[index, "chargedown"]
                new_chargedown = randomize_Legendary(old_chargedown, True)
                if random.randint(4,8) == 8: #Chance to (almost) remove chargedown
                    temp_df["chargedown"] = 0.05
                else:
                    temp_df["chargedown"] = new_chargedown

            # Randomize burst size
            if not pandas.isnull(row["burst size"]):
                old_burst_size = v_weapons.at[index, "burst size"]
                new_burst_size = randomize_Legendary(old_burst_size)
                if random.randint(4,8) == 8: #Chance to add burst to non burst weapons
                    temp_df["burst size"] = new_burst_size +random.randint(1,10)
                else:
                    temp_df["burst size"] = new_burst_size

            # Randomize burst delay (float)
            if not pandas.isnull(row["burst delay"]):
                old_burst_delay = v_weapons.at[index, "burst delay"]
                new_burst_delay = randomize_Legendary(old_burst_delay, True)
                if random.randint(4,8) == 8: #Chance to (almost) remove delay
                    temp_df["burst delay"] = 0.01
                else:
                    temp_df["burst delay"] = new_burst_delay

            # Randomize min spread
            if not pandas.isnull(row["min spread"]):
                old_min_spread = v_weapons.at[index, "min spread"]
                new_min_spread = randomize_Legendary(old_min_spread)
                temp_df["min spread"] = new_min_spread

            # Randomize max spread
            if not pandas.isnull(row["max spread"]):
                old_max_spread = v_weapons.at[index, "max spread"]
                new_max_spread = randomize_Legendary(old_max_spread)
                temp_df["max spread"] = new_max_spread

            # Randomize proj speed
            if not pandas.isnull(row["proj speed"]):
                old_proj_speed = v_weapons.at[index, "proj speed"]
                new_proj_speed = randomize_Legendary(old_proj_speed)
                temp_df["proj speed"] = new_proj_speed

            new_weapons = pandas.concat([new_weapons, temp_df])


    else:
        print("row skipped because weird name")
print(new_weapons)
new_weapons.to_csv(newcsvloc, index=False)
description.to_csv(newDesccsvloc, index=False)
   